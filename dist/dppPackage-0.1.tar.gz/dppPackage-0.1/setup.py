from setuptools import setup

setup(
    name='dppPackage',
    version='0.1',
    packages=['package'],
    license='MIT',
    description='Moja biblioteka',
    #long_description=open('README.txt').read(),
    url='https://git.e-science.pl/mharazin238652/ShoppingListPythonLibrary.git',
    author='Mateusz Harazin',
    author_email='mharazin238652@e-science.pl'
)